# Travel Booking Website - System Design Document

---

## 1. PROJECT OVERVIEW

**Project Name:** Travel Booking Website  
**Goal:** Allow users to search, compare, and book hotels/tours  
**Business Model:** Commission-based booking platform (10-15% commission per booking)

**Key Objectives:**
- Provide seamless hotel/tour search and booking experience
- Optimize for SEO to drive organic traffic
- Ensure scalable architecture for growth
- Enable secure payment processing

---

## 2. SITEMAP STRUCTURE (SEO-Optimized)

```
/
├── / (Home)
│   └── Hero search + Featured destinations + Popular hotels
│
├── /destinations
│   ├── /destinations/{country-slug}
│   │   └── /destinations/{country-slug}/{city-slug}
│   │       └── SEO landing page for each destination
│
├── /hotels
│   ├── /hotels/{destination-slug}  (listing page)
│   └── /hotels/{hotel-slug}  (detail page)
│       └── Schema: Hotel, Review, Breadcrumb
│
├── /tours
│   ├── /tours/{destination-slug}  (listing page)
│   └── /tours/{tour-slug}  (detail page)
│
├── /blog
│   ├── /blog/{category}  (Travel guides, tips, destination content)
│   └── /blog/{category}/{article-slug}
│       └── Content clusters for SEO
│
├── /booking
│   ├── /booking/select-room
│   ├── /booking/guest-details
│   ├── /booking/payment
│   └── /booking/confirmation/{booking-id}
│
└── /account
    ├── /account/profile
    ├── /account/bookings
    ├── /account/wishlist
    └── /account/reviews
```

**URL Strategy:**
- Slug-based, human-readable URLs
- Dynamic routes for scalability
- Canonical tags to prevent duplicate content
- Breadcrumb navigation on all pages

---

## 3. USER FLOW DIAGRAMS

### 3.1 Main Booking Flow

```
┌─────────────┐
│   Visitor   │
└──────┬──────┘
       │
       v
┌─────────────────────────────┐
│  Search (Location + Dates)  │
└──────────┬──────────────────┘
           │
           v
┌─────────────────────────────┐
│  Filter Results             │
│  (Price, Rating, Amenities) │
└──────────┬──────────────────┘
           │
           v
┌─────────────────────────────┐
│  View Hotel Detail Page     │
│  (Photos, Reviews, Rooms)   │
└──────────┬──────────────────┘
           │
           v
┌─────────────────────────────┐
│  Select Room & Dates        │
└──────────┬──────────────────┘
           │
           v
    ┌──────┴──────┐
    │ Logged in?  │
    └──────┬──────┘
           │
       No  │  Yes
    ┌──────┴──────┐
    v             v
┌─────────┐  ┌─────────────────┐
│ Login/  │  │ Enter Guest     │
│Register │  │ Details         │
└────┬────┘  └────┬────────────┘
     │            │
     v            v
┌─────────────────────────────┐
│  Review Booking Summary     │
└──────────┬──────────────────┘
           │
           v
┌─────────────────────────────┐
│  Payment Processing         │
│  (VNPay/Momo/Stripe)       │
└──────────┬──────────────────┘
           │
           v
┌─────────────────────────────┐
│  Booking Confirmation       │
│  Email + SMS                │
└─────────────────────────────┘
```

### 3.2 Alternative User Flows

**Wishlist Flow:**
```
User → Browse Hotels → Click "Save to Wishlist" → Login (if needed) → Added to Wishlist → View Later → Book
```

**Booking Management Flow:**
```
User → Account → Booking History → Select Booking → View Details → Cancel/Modify → Confirmation
```

**Review Flow:**
```
User → Completed Booking → Email Prompt → Leave Review → Submit → Moderation → Published
```

---

## 4. CORE FEATURES / MODULES

### 4.1 Search System
- **Location Search:** Autocomplete with fuzzy matching (cities, hotels, landmarks)
- **Date Picker:** Check-in/check-out with availability calendar
- **Guest Count:** Adults, children, rooms
- **Filters:** Price range, star rating, amenities, property type
- **Sorting:** Price, rating, popularity, distance

**Tech:** Elasticsearch/Algolia for fast search, debounced input

---

### 4.2 Booking System
- **Availability Check:** Real-time room availability
- **Pricing Engine:** Dynamic pricing based on season, demand
- **Inventory Management:** Prevent overbooking with locking mechanism
- **Checkout Process:** Multi-step form with validation
- **Booking Confirmation:** Email/SMS with booking details + QR code

**Tech:** Redis for inventory locking, queue system for confirmation emails

---

### 4.3 Authentication System
- **Email/Password:** Bcrypt hashing
- **Social Login:** Google, Facebook OAuth
- **JWT Tokens:** Access token (15min) + Refresh token (7 days)
- **Email Verification:** Required for new accounts
- **Password Reset:** Secure token-based reset flow

**Tech:** Passport.js, JWT, nodemailer

---

### 4.4 User Dashboard
- **Profile Management:** Edit personal info, upload avatar
- **Booking History:** View past and upcoming bookings
- **Wishlist:** Save favorite hotels
- **Reviews:** Manage submitted reviews
- **Notifications:** Booking reminders, promotions

---

### 4.5 Admin Panel
- **Hotel Management:** CRUD operations, image upload
- **Booking Management:** View, modify, cancel bookings
- **User Management:** View users, manage permissions
- **Analytics Dashboard:** Revenue, bookings, traffic metrics
- **Review Moderation:** Approve/reject reviews

**Tech:** Admin UI with role-based access control (RBAC)

---

### 4.6 Review & Rating System
- **Rating:** 1-5 stars with breakdown (cleanliness, service, location, value)
- **Review Text:** User comments with character limit
- **Moderation:** Auto-flag inappropriate content
- **Verified Bookings:** Only allow reviews from confirmed bookings
- **Aggregation:** Calculate average rating, display distribution

---

## 5. DATABASE STRUCTURE

### 5.1 Schema Design

```
┌─────────────────────┐
│      USERS          │
├─────────────────────┤
│ id (PK)             │
│ email (unique)      │
│ password_hash       │
│ name                │
│ phone               │
│ avatar_url          │
│ role (enum)         │
│ created_at          │
│ updated_at          │
└──────────┬──────────┘
           │
           │ 1:N
           v
┌─────────────────────┐
│     BOOKINGS        │
├─────────────────────┤
│ id (PK)             │
│ user_id (FK)        │◄────┐
│ room_id (FK)        │     │
│ check_in_date       │     │
│ check_out_date      │     │
│ guests_count        │     │
│ total_price         │     │
│ status (enum)       │     │
│ payment_status      │     │
│ payment_method      │     │
│ booking_code        │     │
│ created_at          │     │
└──────────┬──────────┘     │
           │                │
           │ N:1            │
           v                │
┌─────────────────────┐     │
│       ROOMS         │     │
├─────────────────────┤     │
│ id (PK)             │     │
│ hotel_id (FK)       │     │
│ name                │     │
│ type                │     │
│ capacity            │     │
│ price_per_night     │     │
│ amenities (JSON)    │     │
│ images (JSON)       │     │
│ total_rooms         │     │
└──────────┬──────────┘     │
           │                │
           │ N:1            │
           v                │
┌─────────────────────┐     │
│      HOTELS         │     │
├─────────────────────┤     │
│ id (PK)             │     │
│ name                │     │
│ slug (unique)       │     │
│ location_id (FK)    │     │
│ address             │     │
│ description         │     │
│ star_rating         │     │
│ amenities (JSON)    │     │
│ images (JSON)       │     │
│ latitude            │     │
│ longitude           │     │
│ check_in_time       │     │
│ check_out_time      │     │
│ created_at          │     │
└──────────┬──────────┘     │
           │                │
           │ N:1            │
           v                │
┌─────────────────────┐     │
│     LOCATIONS       │     │
├─────────────────────┤     │
│ id (PK)             │     │
│ city                │     │
│ country             │     │
│ slug (unique)       │     │
│ description         │     │
│ image_url           │     │
└─────────────────────┘     │
                            │
┌─────────────────────┐     │
│      REVIEWS        │     │
├─────────────────────┤     │
│ id (PK)             │     │
│ user_id (FK)        │─────┘
│ hotel_id (FK)       │
│ booking_id (FK)     │ (verify booking)
│ rating              │
│ cleanliness_rating  │
│ service_rating      │
│ location_rating     │
│ value_rating        │
│ comment             │
│ status (enum)       │
│ created_at          │
└─────────────────────┘

┌─────────────────────┐
│     CATEGORIES      │
├─────────────────────┤
│ id (PK)             │
│ name                │
│ slug (unique)       │
│ description         │
└─────────────────────┘

┌─────────────────────┐
│   BLOG_POSTS        │
├─────────────────────┤
│ id (PK)             │
│ category_id (FK)    │
│ author_id (FK)      │
│ title               │
│ slug (unique)       │
│ content (text)      │
│ excerpt             │
│ featured_image      │
│ meta_title          │
│ meta_description    │
│ published_at        │
│ created_at          │
└─────────────────────┘

┌─────────────────────┐
│     WISHLISTS       │
├─────────────────────┤
│ id (PK)             │
│ user_id (FK)        │
│ hotel_id (FK)       │
│ created_at          │
└─────────────────────┘
```

### 5.2 Key Relationships
- `Users` ↔ `Bookings` (1:N)
- `Hotels` ↔ `Rooms` (1:N)
- `Rooms` ↔ `Bookings` (1:N)
- `Hotels` ↔ `Reviews` (1:N)
- `Users` ↔ `Reviews` (1:N)
- `Hotels` ↔ `Locations` (N:1)
- `Users` ↔ `Wishlists` ↔ `Hotels` (M:N)

---

## 6. BACKEND ARCHITECTURE

### 6.1 Technology Stack
- **Runtime:** Node.js (v20+)
- **Framework:** Express.js or NestJS
- **Database:** PostgreSQL (primary), Redis (caching)
- **ORM:** Prisma or TypeORM
- **Authentication:** JWT + Passport.js
- **File Storage:** AWS S3 or Cloudinary
- **Email:** SendGrid or AWS SES
- **Payment:** Stripe, VNPay, Momo

### 6.2 API Structure (REST)

```
POST   /api/auth/register
POST   /api/auth/login
POST   /api/auth/refresh-token
POST   /api/auth/forgot-password
POST   /api/auth/reset-password

GET    /api/hotels?location={}&check_in={}&check_out={}
GET    /api/hotels/:slug
GET    /api/hotels/:id/rooms
GET    /api/hotels/:id/reviews

POST   /api/search
POST   /api/bookings
GET    /api/bookings/:id
PUT    /api/bookings/:id/cancel
GET    /api/users/me/bookings

POST   /api/reviews
GET    /api/reviews/:id
PUT    /api/reviews/:id
DELETE /api/reviews/:id

POST   /api/wishlist
GET    /api/wishlist
DELETE /api/wishlist/:hotel_id

POST   /api/payments/create-intent
POST   /api/payments/webhook
GET    /api/payments/:id/status

GET    /api/locations
GET    /api/locations/:slug

GET    /api/blog/posts
GET    /api/blog/posts/:slug
GET    /api/blog/categories
```

### 6.3 Service Architecture

```
┌────────────────────┐
│   API Gateway      │
│   (Express/NestJS) │
└─────────┬──────────┘
          │
    ┌─────┴─────────────────────────┐
    │                               │
    v                               v
┌──────────────┐            ┌──────────────┐
│ Auth Service │            │Search Service│
└──────────────┘            └──────────────┘
    │                               │
    v                               v
┌──────────────┐            ┌──────────────┐
│Booking Svc   │◄───────────│ Payment Svc  │
└──────────────┘            └──────────────┘
    │                               │
    v                               v
┌──────────────┐            ┌──────────────┐
│Notification  │            │ Email Service│
│   Service    │            └──────────────┘
└──────────────┘
    │
    v
┌────────────────────────────┐
│      PostgreSQL            │
│   (Primary Database)       │
└────────────────────────────┘

┌────────────────────────────┐
│         Redis              │
│  (Cache + Session Store)   │
└────────────────────────────┘
```

### 6.4 Payment Integration Flow

```
User → Frontend → Backend API → Payment Provider (VNPay/Stripe)
                      │                    │
                      │◄───── Webhook ─────┘
                      │
                      v
              Update Booking Status
                      │
                      v
              Send Confirmation Email
```

---

## 7. FRONTEND ARCHITECTURE

### 7.1 Technology Stack
- **Framework:** Next.js 14 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **State Management:** Zustand + React Context
- **Data Fetching:** React Query (TanStack Query)
- **Forms:** React Hook Form + Zod validation
- **UI Components:** Shadcn/ui or custom components

### 7.2 Folder Structure

```
src/
├── app/
│   ├── layout.tsx
│   ├── page.tsx (Home)
│   ├── destinations/
│   │   ├── [country]/
│   │   │   └── [city]/
│   │   │       └── page.tsx
│   ├── hotels/
│   │   ├── [destination]/
│   │   │   └── page.tsx (listing)
│   │   └── [slug]/
│   │       └── page.tsx (detail)
│   ├── booking/
│   │   ├── select-room/page.tsx
│   │   ├── guest-details/page.tsx
│   │   ├── payment/page.tsx
│   │   └── confirmation/[id]/page.tsx
│   ├── account/
│   │   ├── profile/page.tsx
│   │   ├── bookings/page.tsx
│   │   └── wishlist/page.tsx
│   └── blog/
│       ├── [category]/page.tsx
│       └── [category]/[slug]/page.tsx
│
├── components/
│   ├── ui/ (Button, Input, Card, etc.)
│   ├── layout/ (Header, Footer, Sidebar)
│   ├── search/ (SearchBar, Filters, DatePicker)
│   ├── hotel/ (HotelCard, HotelGallery, ReviewList)
│   └── booking/ (BookingForm, PaymentForm, Summary)
│
├── lib/
│   ├── api/ (API client functions)
│   ├── utils/ (helpers, formatters)
│   ├── hooks/ (custom React hooks)
│   └── validators/ (Zod schemas)
│
├── stores/
│   ├── useBookingStore.ts
│   └── useAuthStore.ts
│
└── styles/
    └── globals.css
```

### 7.3 State Management Strategy

**Zustand Stores:**
- `useAuthStore` - User auth state, JWT tokens
- `useBookingStore` - Current booking flow data (dates, guests, selected room)
- `useSearchStore` - Search filters, results

**React Query:**
- Server state caching for hotels, bookings, user data
- Automatic refetching and cache invalidation
- Optimistic updates for wishlist, reviews

### 7.4 API Integration Pattern

```typescript
// React Query hook example
import { useQuery } from '@tanstack/react-query';

export const useHotelDetails = (slug: string) => {
  return useQuery({
    queryKey: ['hotel', slug],
    queryFn: () => api.hotels.getBySlug(slug),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
};
```

---

## 8. SEO STRATEGY

### 8.1 On-Page SEO

**Meta Tags Strategy:**
```typescript
// Hotel detail page example
export const metadata = {
  title: `${hotelName} - Book Now | Travel Booking`,
  description: `Book ${hotelName} in ${city}. ${star}⭐ hotel with ${amenities}. From $${price}/night. Free cancellation.`,
  openGraph: {
    title: hotelName,
    description: excerpt,
    images: [hotelImage],
  },
};
```

**Dynamic Meta Tags:**
- Home: "Book Hotels & Tours | Best Prices Guaranteed"
- Destination: "Hotels in {City}, {Country} | Compare & Book"
- Hotel Detail: "{Hotel Name} - {Star}⭐ Hotel in {City} from ${Price}/night"
- Blog: "{Article Title} | Travel Guides & Tips"

### 8.2 Schema Markup

**Hotel Schema:**
```json
{
  "@context": "https://schema.org",
  "@type": "Hotel",
  "name": "Hotel Name",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "123 Main St",
    "addressLocality": "City",
    "addressCountry": "Country"
  },
  "starRating": {
    "@type": "Rating",
    "ratingValue": "4.5"
  },
  "priceRange": "$$",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.5",
    "reviewCount": "150"
  }
}
```

**Review Schema, Breadcrumb Schema, FAQPage Schema** - implement on relevant pages

### 8.3 Content Strategy

**SEO Content Clusters:**
```
Hub Page: "Best Hotels in Vietnam"
    ↓
├── "Best Hotels in Hanoi"
├── "Best Hotels in Ho Chi Minh City"  
├── "Best Hotels in Da Nang"
└── "Best Beachfront Hotels in Vietnam"
    ↓
Individual hotel pages (with internal links back to cluster pages)
```

**Blog Content Types:**
- Destination Guides: "10 Best Things to Do in Bali"
- Travel Tips: "How to Book Cheap Hotels"
- Itineraries: "5-Day Vietnam Travel Itinerary"
- Seasonal Content: "Best Summer Destinations in Asia"

### 8.4 Technical SEO

- **XML Sitemap:** Auto-generated with Next.js sitemap.ts
- **Robots.txt:** Allow all, specify sitemap location
- **Canonical URLs:** Prevent duplicate content
- **Internal Linking:** Related hotels, destination pages, blog posts
- **URL Structure:** Short, descriptive, keyword-rich
- **Image Alt Tags:** Descriptive alt text for all images
- **Page Speed:** Target < 3s LCP, < 100ms FID

### 8.5 Keyword Targeting

**Primary Keywords:**
- "book hotels in {city}"
- "best hotels in {destination}"
- "{city} hotel deals"
- "cheap hotels near {landmark}"

**Long-tail Keywords:**
- "family-friendly hotels in {city}"
- "luxury hotels with pool in {destination}"
- "budget hotels near {airport} with free shuttle"

---

## 9. PERFORMANCE & SCALING

### 9.1 Caching Strategy

**Redis Cache Layers:**
```
┌────────────────────────────────────┐
│  Browser Cache (Static Assets)    │
│  Cache-Control: max-age=31536000  │
└────────────────────────────────────┘
                │
                v
┌────────────────────────────────────┐
│  CDN Cache (Images, CSS, JS)       │
│  Cloudflare / Vercel Edge          │
└────────────────────────────────────┘
                │
                v
┌────────────────────────────────────┐
│  Redis Cache (Application Layer)   │
│  - Search results (5 min TTL)      │
│  - Hotel details (15 min TTL)      │
│  - Location data (1 hour TTL)      │
│  - User sessions                   │
└────────────────────────────────────┘
                │
                v
┌────────────────────────────────────┐
│  Database (PostgreSQL)              │
│  - Primary data source              │
│  - Read replicas for scaling        │
└────────────────────────────────────┘
```

**Cache Invalidation:**
- Hotel data: On admin update
- Search results: Time-based expiry
- User bookings: On create/update/cancel

### 9.2 Database Optimization

**Indexing Strategy:**
```sql
-- Hotels table
CREATE INDEX idx_hotels_location ON hotels(location_id);
CREATE INDEX idx_hotels_slug ON hotels(slug);
CREATE INDEX idx_hotels_rating ON hotels(star_rating);

-- Bookings table
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_bookings_dates ON bookings(check_in_date, check_out_date);
CREATE INDEX idx_bookings_status ON bookings(status);

-- Search optimization
CREATE INDEX idx_hotels_search ON hotels USING gin(to_tsvector('english', name || ' ' || description));
```

**Query Optimization:**
- Use connection pooling (pg-pool)
- Implement pagination (limit/offset)
- Use SELECT only required fields
- Implement read replicas for heavy read operations

### 9.3 Frontend Performance

**Next.js Optimization:**
```typescript
// Image optimization
<Image 
  src={hotelImage}
  alt={hotelName}
  width={800}
  height={600}
  loading="lazy"
  quality={85}
  placeholder="blur"
/>

// Dynamic imports for heavy components
const MapView = dynamic(() => import('@/components/MapView'), {
  loading: () => <MapSkeleton />,
  ssr: false,
});

// Route prefetching
<Link href="/hotels/luxury-resort" prefetch={true}>
```

**Bundle Optimization:**
- Code splitting by route
- Tree shaking unused code
- Minimize dependencies
- Use Brotli compression

### 9.4 CDN Strategy

**Static Assets:**
- Images: Cloudinary with automatic format conversion (WebP, AVIF)
- JS/CSS: Vercel Edge Network or Cloudflare CDN
- Fonts: Google Fonts with font-display: swap

**Geographic Distribution:**
- Deploy edge functions near users
- Use CDN PoPs in target markets (Asia, Europe, US)

### 9.5 Monitoring & Alerting

**Performance Monitoring:**
- **Vercel Analytics:** Core Web Vitals (LCP, FID, CLS)
- **Sentry:** Error tracking, performance tracing
- **New Relic/DataDog:** Backend API performance
- **Uptime Robot:** Endpoint availability monitoring

**Alerts:**
- API response time > 500ms
- Error rate > 1%
- Database CPU > 80%
- Redis memory > 90%

---

## 10. ANALYTICS & TRACKING

### 10.1 Google Analytics 4 Setup

**Event Tracking:**
```typescript
// Search event
gtag('event', 'search', {
  search_term: location,
  check_in: checkInDate,
  check_out: checkOutDate,
  guests: guestsCount,
});

// View hotel event
gtag('event', 'view_item', {
  items: [{
    item_id: hotel.id,
    item_name: hotel.name,
    price: hotel.price,
    item_category: hotel.location,
  }],
});

// Add to cart (select room)
gtag('event', 'add_to_cart', {
  items: [{ item_id: room.id, price: totalPrice }],
});

// Purchase (booking complete)
gtag('event', 'purchase', {
  transaction_id: booking.id,
  value: booking.totalPrice,
  currency: 'USD',
  items: [{ item_id: room.id }],
});
```

### 10.2 Conversion Funnel Tracking

```
┌────────────────────┐
│  Landing Page      │ 100%
└─────────┬──────────┘
          │
          v
┌────────────────────┐
│  Search Results    │ 60%  (40% drop-off)
└─────────┬──────────┘
          │
          v
┌────────────────────┐
│  Hotel Detail      │ 40%  (20% drop-off)
└─────────┬──────────┘
          │
          v
┌────────────────────┐
│  Select Room       │ 25%  (15% drop-off)
└─────────┬──────────┘
          │
          v
┌────────────────────┐
│  Guest Details     │ 20%  (5% drop-off)
└─────────┬──────────┘
          │
          v
┌────────────────────┐
│  Payment           │ 15%  (5% drop-off)
└─────────┬──────────┘
          │
          v
┌────────────────────┐
│  Confirmation      │ 12%  (3% drop-off)
└────────────────────┘
```

**Optimization Targets:**
- Reduce drop-off from search → detail (add better filters)
- Reduce drop-off from detail → select room (clearer CTAs)
- Reduce drop-off from payment (add trust badges, multiple payment methods)

### 10.3 User Behavior Tracking

**Heatmaps & Session Recording:**
- Hotjar or Microsoft Clarity
- Track: Click maps, scroll depth, rage clicks, dead clicks
- Record sessions for UX analysis

**A/B Testing:**
- Test CTA button colors
- Test hotel card layouts
- Test checkout flow variations
- Tool: Google Optimize or Vercel Edge Config

### 10.4 Business Metrics Dashboard

**Key Metrics to Track:**
- **Conversion Rate:** (Bookings / Visitors) × 100
- **Average Booking Value (ABV):** Total Revenue / Number of Bookings
- **Customer Acquisition Cost (CAC):** Marketing Spend / New Customers
- **Lifetime Value (LTV):** Average bookings per user × ABV
- **Search-to-Book Rate:** Bookings / Total Searches
- **Cancellation Rate:** Cancelled Bookings / Total Bookings

**Analytics Platform:**
- Custom dashboard with Metabase or Grafana
- Data source: PostgreSQL analytics database (replicated from primary)

### 10.5 Marketing Attribution

**Track Traffic Sources:**
- Organic Search (SEO)
- Paid Search (Google Ads)
- Social Media (Facebook, Instagram)
- Referral (Partner sites, influencers)
- Direct (Returning users)

**UTM Parameters:**
```
https://travelbooking.com/hotels/bali?utm_source=facebook&utm_medium=cpc&utm_campaign=summer2026&utm_content=carousel-ad
```

---

## 11. DEPLOYMENT & INFRASTRUCTURE

### 11.1 Hosting Architecture

```
┌─────────────────────────────────────────────┐
│           Cloudflare / DNS                  │
└──────────────────┬──────────────────────────┘
                   │
        ┌──────────┴──────────┐
        │                     │
        v                     v
┌───────────────┐      ┌─────────────────┐
│   Frontend    │      │    Backend API   │
│  (Vercel/     │      │   (AWS EC2 /     │
│   Netlify)    │      │    Railway)      │
└───────────────┘      └────────┬─────────┘
                                │
                    ┌───────────┴───────────┐
                    │                       │
                    v                       v
          ┌──────────────────┐    ┌─────────────────┐
          │   PostgreSQL     │    │     Redis       │
          │  (AWS RDS /      │    │   (Upstash /    │
          │   Supabase)      │    │    Railway)     │
          └──────────────────┘    └─────────────────┘

          ┌──────────────────┐    ┌─────────────────┐
          │   File Storage   │    │  Email Service  │
          │  (AWS S3 /       │    │   (SendGrid)    │
          │   Cloudinary)    │    └─────────────────┘
          └──────────────────┘
```

### 11.2 CI/CD Pipeline

```
GitHub Push → GitHub Actions
    │
    ├── Run Tests (Jest, Playwright)
    │
    ├── Build Frontend (Next.js)
    │   └── Deploy to Vercel (Preview for PRs, Production for main)
    │
    ├── Build Backend (Node.js)
    │   └── Deploy to Railway/AWS (Staging → Production)
    │
    └── Run Migrations (Prisma)
```

### 11.3 Environment Setup

**Environments:**
- **Development:** Local (localhost:3000, localhost:5000)
- **Staging:** staging.travelbooking.com (test payment, real-like data)
- **Production:** travelbooking.com (live users)

**Environment Variables:**
```env
# Database
DATABASE_URL=postgresql://...
REDIS_URL=redis://...

# Auth
JWT_SECRET=...
JWT_EXPIRY=15m
REFRESH_TOKEN_EXPIRY=7d

# Payment
STRIPE_SECRET_KEY=...
VNPAY_TMN_CODE=...
VNPAY_HASH_SECRET=...

# Email
SENDGRID_API_KEY=...
FROM_EMAIL=noreply@travelbooking.com

# Storage
AWS_S3_BUCKET=...
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...

# Analytics
GA_MEASUREMENT_ID=G-XXXXXXXXXX
```

---

## 12. SECURITY CONSIDERATIONS

### 12.1 Authentication Security
- Bcrypt password hashing (salt rounds: 12)
- JWT with short expiry (15 min access, 7 day refresh)
- HTTP-only cookies for refresh tokens
- CSRF protection with tokens
- Rate limiting on login/register endpoints (5 attempts / 15 min)

### 12.2 Data Security
- SQL injection prevention (use parameterized queries)
- XSS prevention (sanitize user inputs, use Content Security Policy)
- Input validation on all forms (Zod schemas)
- Helmet.js for security headers
- HTTPS everywhere (TLS 1.3)

### 12.3 Payment Security
- PCI DSS compliance (use Stripe for card processing)
- Never store full credit card numbers
- Webhook signature verification
- Secure payment redirect flow

### 12.4 API Security
- API rate limiting (100 requests / 15 min per IP)
- API key authentication for admin endpoints
- CORS policy (whitelist frontend domains)
- Request validation middleware

---

## 13. TESTING STRATEGY

### 13.1 Backend Testing
- **Unit Tests:** Jest for service functions
- **Integration Tests:** Supertest for API endpoints
- **Database Tests:** Test database with seed data
- **Coverage Target:** 80%+

### 13.2 Frontend Testing
- **Unit Tests:** Jest + React Testing Library for components
- **E2E Tests:** Playwright for critical flows (search → book → pay)
- **Visual Regression:** Chromatic or Percy
- **Accessibility:** axe-core, WAVE

### 13.3 Critical Test Scenarios
- Complete booking flow (happy path)
- Payment failure handling
- Concurrent booking prevention (same room)
- Search with filters
- User authentication flow

---

## 14. FUTURE ENHANCEMENTS (ROADMAP)

### Phase 1 (MVP) - Months 1-3
- ✅ Search & booking flow
- ✅ Payment integration
- ✅ User authentication
- ✅ Basic admin panel

### Phase 2 - Months 4-6
- Multi-language support (i18n)
- Multi-currency support
- Email marketing automation
- Advanced filters (map view, amenity search)
- Mobile app (React Native)

### Phase 3 - Months 7-12
- AI-powered recommendations
- Chatbot support (customer service)
- Loyalty program
- Dynamic pricing algorithm
- Partner hotel API integration

---

## 15. CONCLUSION

This system design provides a comprehensive blueprint for building a scalable, SEO-optimized travel booking platform. The architecture prioritizes:

1. **User Experience:** Fast search, smooth booking flow, responsive design
2. **SEO Performance:** Optimized content structure, schema markup, fast page loads
3. **Scalability:** Caching layers, database optimization, CDN usage
4. **Security:** Secure auth, payment processing, data protection
5. **Analytics:** Comprehensive tracking for continuous optimization

**Next Steps:**
1. Set up development environment
2. Initialize Next.js project with folder structure
3. Design database schema in PostgreSQL
4. Build MVP features (search, booking, payment)
5. Implement SEO foundation (meta tags, schema, sitemap)
6. Launch beta and gather user feedback

---

**Document Version:** 1.0  
**Last Updated:** April 27, 2026  
**Author:** System Design Team
