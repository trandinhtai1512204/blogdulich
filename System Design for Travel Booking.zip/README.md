
  # System Design for Travel Booking

  This is a code bundle for System Design for Travel Booking. The original project is available at https://www.figma.com/design/Tpk8DK1sgeAdfllvuKHbVX/System-Design-for-Travel-Booking.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  